
<p align="center">
  <img src="./assets/matrix-header.gif" alt="header animado estilo matrix" />
</p>

<h1 align="center">Olá, eu sou o Allan Lopes! 👋</h1>

<p align="center">
  Desenvolvedor FullStack apaixonado por negócios, inovação e transformar ideias em soluções digitais reais.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" />
  <img src="https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white" />
  <img src="https://img.shields.io/badge/Next.js-000000?style=for-the-badge&logo=nextdotjs&logoColor=white" />
  <img src="https://img.shields.io/badge/Tailwind-06B6D4?style=for-the-badge&logo=tailwindcss&logoColor=white" />
</p>

---

## 👨‍💻 Sobre mim

💼 Co-fundador da Vertrauem  
🚀 Criador dos sistemas **SIGOS** e **Vetorize**  
📈 Focado em criar soluções reais para negócios locais  
🐶 Tenho um doguinho chamado **Joey** (sim, do Friends!)  
🎯 Sempre aprendendo, sempre construindo.

---

## 🛠️ Projetos em destaque

- 🔧 **Vetorize**: sistema completo para empresas de dedetização
- 📋 **SIGOS**: controle de ordens de serviço com fluxo financeiro
- ✅ **TaskCollab**: app colaborativo para gestão de tarefas (em desenvolvimento)

---

## 📫 Entre em contato

[![LinkedIn](https://img.shields.io/badge/-LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/allanlps/)
[![Email](https://img.shields.io/badge/-Email-EA4335?style=for-the-badge&logo=gmail&logoColor=white)](mailto:allanlps20@gmail.com)

---

<p align="center">
  Feito com 💻, ☕ e muito 🔥 por Allan Lopes
</p>
